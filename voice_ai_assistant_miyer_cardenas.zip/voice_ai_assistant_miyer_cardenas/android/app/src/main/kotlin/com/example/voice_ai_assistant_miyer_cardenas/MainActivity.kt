package com.example.voice_ai_assistant_miyer_cardenas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
